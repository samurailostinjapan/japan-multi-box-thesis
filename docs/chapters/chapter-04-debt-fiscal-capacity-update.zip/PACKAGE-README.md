# Chapter 4 update package

Copy the `docs` directory over the repository's existing `docs` directory.

Files replaced:

- `docs/chapters/04-debt-fiscal-capacity.md`
- `docs/sources.md`

Then build locally with:

```bash
mkdocs build --strict
```

Review the Git diff before committing.
